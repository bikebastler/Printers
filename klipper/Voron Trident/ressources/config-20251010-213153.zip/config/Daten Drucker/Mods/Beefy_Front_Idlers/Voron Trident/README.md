## Pictures:
- Front Idlers for Trident by TadasMit:
![](./1.jpg)
![](./2.jpg)
###### Pictures:
##### Alpha Version:
![](https://github.com/Ramalama2/Voron-2-Mods/raw/main/Front_Idlers/Pics/Assembly_Front-Idlers55.jpg)
##### Older Pics:
![](https://github.com/Ramalama2/Voron-2-Mods/raw/main/Front_Idlers/Pics/Assy1.jpg)
![](https://github.com/Ramalama2/Voron-2-Mods/raw/main/Front_Idlers/Pics/Assy2.jpg)
![](https://github.com/Ramalama2/Voron-2-Mods/raw/main/Front_Idlers/Pics/Assy3.jpg)
![](https://github.com/Ramalama2/Voron-2-Mods/raw/main/Front_Idlers/Pics/Assy4.jpg)
![](https://github.com/Ramalama2/Voron-2-Mods/raw/main/Front_Idlers/Pics/Assy5.jpg)
